%% Devices.Newport.XPS
apiCurrentVersion=''; %One of {'current'}

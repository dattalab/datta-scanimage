%function outputData = grabFrame(obj, varargin)
%   See QCam API documentation for function details.
%   NOTES: 
%
%   outputData: Array of output data.
%

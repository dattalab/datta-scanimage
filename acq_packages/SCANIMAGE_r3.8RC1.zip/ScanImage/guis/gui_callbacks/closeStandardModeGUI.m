function closeStandardModeGUI
	global gh
	try
		hideGUI('gh.standardModeGUI.figure1');
	end
	
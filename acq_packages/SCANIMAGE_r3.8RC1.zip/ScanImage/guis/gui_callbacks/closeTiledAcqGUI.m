function closeTiledAcqGUI
	global gh
	try
		hideGUI('gh.tiledAcqGUI.figure1');
	end
	
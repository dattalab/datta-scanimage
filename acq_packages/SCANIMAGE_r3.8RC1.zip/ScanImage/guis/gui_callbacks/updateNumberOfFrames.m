function  updateNumberOfFrames(varargin)
%% function  updateNumberOfFrames(varargin)

resetCounters();
updateNumAvgFramesSave();

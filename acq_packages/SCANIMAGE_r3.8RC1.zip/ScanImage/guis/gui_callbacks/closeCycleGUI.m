function closeCycleGUI
	global gh
	try
		hideGUI('gh.cycleGUI.figure1');
	end
	
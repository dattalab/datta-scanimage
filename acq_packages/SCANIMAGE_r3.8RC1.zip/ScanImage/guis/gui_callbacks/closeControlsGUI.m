function closeControlsGUI
global state gh

try
	hideGUI('gh.cycleGUI.figure1');
end
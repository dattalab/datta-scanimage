function closeCurrentFigures
%close req function for imaging windows

try
	closereq
catch
end

function out_obj = loadobj(obj)
%LOADOBJ   - @program save overloaded function.
%  LOADOBJ(obj) will load the LOADOBJ script prior to reading the object
%  from disk.
%
%  See also SAVEOBJ

out_obj=obj;
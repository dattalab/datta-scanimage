function pointer = getPointer(this)

pointer = this.ptr;

return;
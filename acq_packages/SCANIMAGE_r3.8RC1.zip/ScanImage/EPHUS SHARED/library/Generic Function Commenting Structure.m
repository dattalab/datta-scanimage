% GENERICFUNCTION   - One line description of function followed by a period.
%   GENERICFUNCTION(input1,input2,...) longer multiple line description.
% 
% 	More descriptions.
%
%   Examples:
% 
% 	See also GENERICFUNCTION2, GENERICFUNCTION3
% 
%   Overloaded methods
%       help directory/topic.m

% 	Changes:
% 		Name_Date_Edit  - Description of change to file.

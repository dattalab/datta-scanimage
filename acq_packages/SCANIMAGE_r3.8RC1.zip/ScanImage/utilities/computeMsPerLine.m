function [fillFraction, msPerLine] = applyIncrementMultiplier(incrementMultiplier)
%COMPUTEMSPERLINE Computes msPerLine value from increment-multiplier value
%
%% CREDITS
%   Created 1/21/09, by Vijay Iyer
%% ******************************************

global state



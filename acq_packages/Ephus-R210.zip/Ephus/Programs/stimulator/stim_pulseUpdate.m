% stim_pulseUpdate - Callback for updating the selected pulses when changed externally.
%
% SYNTAX
%  stim_pulseUpdate(hObject)
%
% USAGE
%
% NOTES
%
% CHANGES
%
% Created 2/24/06 Tim O'Connor
% Copyright - Cold Spring Harbor Laboratories/Howard Hughes Medical Institute 2006
function stim_pulseUpdate(hObject)

return;
qc = program('qcam', 'qcam', 'qcam');
openprogram(progmanager, qc);
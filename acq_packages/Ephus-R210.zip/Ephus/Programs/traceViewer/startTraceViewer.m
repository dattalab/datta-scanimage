function startTraceViewer

tv = program('traceViewer', 'traceViewer', 'traceViewer');

openprogram(progmanager, tv);

return;
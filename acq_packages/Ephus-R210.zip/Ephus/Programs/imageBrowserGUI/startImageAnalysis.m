function startImageAnalysis

openprogram(progmanager, program('stackBrowserControl', 'StackBrowserControl', 'stackBrowserControl', ...
    'stackBrowserOptions', 'stackBrowserOptions', 'stackBrowserDisplayOptions', 'stackBrowserDisplayOptions', ...
    'stackBrowserFeatureRecognitionOptions', 'stackBrowserFeatureRecognitionOptions'))

return;
% Svoboda Lab Library - Array Handling Functions
% 
% These functions are generic and can be used on numeric arrays.
%  	
% Padding
%   padlength    	- Pads numeric array with specified value.

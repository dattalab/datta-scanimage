% ------------------------------------------------------------------
function serialControlStruct = makeSerialControlStruct

serialControlStruct.lastCommand = '';
serialControlStruct.lastResponse = '';
serialControlStruct.timeOutOccurred = 0;

return;
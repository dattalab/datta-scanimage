% Svoboda Lab Library - Development Environment Tools
% 
% These functions aid the programmer in documentation, commenting,
% etc...
%  	
% Help Interface Generation (Contents.m files)
%   FORMATDIRECTORYFORCONTENTS   - Outputs H1 Line from m-files in directory as a character array.
% 	CHECKCONTENTSFORUPDATES   - Outputs H1 lines for m files in directory that are not in Contents.                                 

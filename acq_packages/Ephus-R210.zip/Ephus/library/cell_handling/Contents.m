% Svoboda Lab Library - Cell Array Handling Functions
% 
% These functions are generic and can be used on cell arrays.
%  	
% Cell Array of Strings
% 	FINDSTRINCELL   - locates indices of string in cell array of strings.
% 	FINDSTRINCELLI   - locates indices of string in cell array of strings ignoring case.

% Svoboda Lab Library - Logical Functions
% 
% These are a collection of useful logical comparison functions that were
% not included in MATLAB.
% 
% Handle Graphics Specific
%   ISTYPE   - Checks 'type' of handle.
%
% File I/O
% 	DOESFILEEXIST   - checks if file exists.



